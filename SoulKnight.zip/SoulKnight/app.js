const express = require('express');
const handlebars = require('express-handlebars');

const app = express();



app.engine('handlebars', handlebars.engine());
app.set('view engine', 'handlebars');

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('index', {
        message: "Quick Navigation"
    });
});

app.get('/bosses', (req,res) => {
    res.render('bosses', {
        message: "Bosses"
    });
});

app.get("/weapons", (req,res) => {
    res.render('weapons', {
        message: "Weapons"
    });
})

app.get("/mounts", (req,res) => {
    res.render('mounts', {
        message: "Mounts"
    });
})


app.use((req, res) => {
    res.status(404).send('<h1>404, page not found</h1>')
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`server is running on https://127.0.0.1:${PORT}`);
});